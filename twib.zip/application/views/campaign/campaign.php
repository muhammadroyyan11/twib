 <!--================Banner Area =================-->
 <section class="banner_area">
     <div class="container">
         <div class="banner_inner_text">
             <h2>Campaign Saya</h2>
             <p></p>
         </div>
     </div>
 </section>
 <!--================End Banner Area =================-->


 <!--================Feature Area =================-->
 <!-- <div class="pull-right" style="margin-right: 12%;">
     <a href="<?= site_url('campaign/add') ?>" class="btn btn-primary btn-flat">
         <i class="fa fa-files-plus"></i>+ Tambah
     </a>
 </div> -->
 <div class="col-lg-12 col-md-12">
     <a href="<?= site_url('campaign/add') ?>" class="btn btn-primary btn-flat">
         <i class="fa fa-files-plus"></i>+ Tambah
     </a>

 </div>
 <section class="feature_area">

     <div class="container">
         <div class="row">
             <div class="col-lg-4 col-md-6">
                 <div class="card" style="width: 22rem;">
                     <img class="card-img-top" src="<?= base_url() ?>assets/img/blog/twib.png" alt="Card image cap">
                     <div class="card-body">
                         <h4>
                             <p class="explore__subtitle m-0 p-0">JUDUL</p>
                         </h4>
                         <p><i class="fa fa-user-o" aria-hidden="true"></i> asdasdas</p>
                         <p><i class="fa fa-clock-o" aria-hidden="true"></i> <?= date('d-m-y') ?></p>
                     </div>
                 </div>
             </div>
             <div class="col-lg-4 col-md-6">
                 <div class="card" style="width: 22rem;">
                     <img class="card-img-top" src="<?= base_url() ?>assets/img/blog/twib.png" alt="Card image cap">
                     <div class="card-body">
                         <h4>
                             <p class="explore__subtitle m-0 p-0">JUDUL</p>
                         </h4>
                         <p><i class="fa fa-user-o" aria-hidden="true"></i> asdasdas</p>
                         <p><i class="fa fa-clock-o" aria-hidden="true"></i> <?= date('d-m-y') ?></p>
                     </div>
                 </div>
             </div>
             <div class="col-lg-4 col-md-6">
                 <div class="card" style="width: 22rem;">
                     <img class="card-img-top" src="<?= base_url() ?>assets/img/blog/twib.png" alt="Card image cap">
                     <div class="card-body">
                         <h4>
                             <p class="explore__subtitle m-0 p-0">JUDUL</p>
                         </h4>
                         <p><i class="fa fa-user-o" aria-hidden="true"></i> asdasdas</p>
                         <p><i class="fa fa-clock-o" aria-hidden="true"></i> <?= date('d-m-y') ?></p>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <br>
 </section>
 <!--================End Feature Area =================-->